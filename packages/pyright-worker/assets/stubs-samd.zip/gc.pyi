"""
Control the garbage collector which automatically frees.

MicroPython module: https://docs.micropython.org/en/v1.29.0/library/gc.html
              :ref:`heap memory <heap>`

CPython module: :mod:`python:gc` https://docs.python.org/3/library/gc.html .

---
Module: 'gc' on micropython-v1.29.0-samd-SEEED_WIO_TERMINAL
"""

# MCU: {'variant': '', 'build': '', 'arch': 'armv7emsp', 'port': 'samd', 'board': 'SEEED_WIO_TERMINAL', 'board_id': 'SEEED_WIO_TERMINAL', 'mpy': 'v6.3', 'ver': '1.29.0', 'family': 'micropython', 'cpu': 'SAMD51P19A', 'version': '1.29.0'}
# Stubber: v1.28.6
from __future__ import annotations

from typing import overload

from _typeshed import Incomplete
from typing_extensions import Awaitable, TypeAlias, TypeVar

def isenabled() -> bool:
    """
    Returns True if automatic garbage collection is enabled, and False otherwise.
    """
    ...

def mem_free() -> int:
    """
    Return the number of bytes of heap RAM that is available for Python
    code to allocate, or -1 if this amount is not known.

    Admonition:Difference to CPython
       :class: attention

       This function is MicroPython extension.
    """
    ...

def mem_alloc() -> int:
    """
    Return the number of bytes of heap RAM that are allocated by Python code.

    Admonition:Difference to CPython
       :class: attention

       This function is MicroPython extension.
    """
    ...

def collect() -> int | None:
    """
    Run a garbage collection.
    """
    ...

def enable() -> None:
    """
    Enable automatic garbage collection.
    """
    ...

def disable() -> None:
    """
    Disable automatic garbage collection.  Heap memory can still be allocated,
    and garbage collection can still be initiated manually using :meth:`gc.collect`.
    """
    ...

@overload
def threshold() -> int:
    """
    Set or query the additional GC allocation threshold. Normally, a collection
    is triggered only when a new allocation cannot be satisfied, i.e. on an
    out-of-memory (OOM) condition. If this function is called, in addition to
    OOM, a collection will be triggered each time after *amount* bytes have been
    allocated (in total, since the previous time such an amount of bytes
    have been allocated). *amount* is usually specified as less than the
    full heap size, with the intention to trigger a collection earlier than when the
    heap becomes exhausted, and in the hope that an early collection will prevent
    excessive memory fragmentation. This is a heuristic measure, the effect
    of which will vary from application to application, as well as
    the optimal value of the *amount* parameter.

    Calling the function without argument will return the current value of
    the threshold. A value of -1 means a disabled allocation threshold.

    Admonition:Difference to CPython
       :class: attention

       This function is a MicroPython extension. CPython has a similar
       function - ``set_threshold()``, but due to different GC
       implementations, its signature and semantics are different.

    Examples
    ^^^^^^^^

    To trigger a garbage collection each time 32768 bytes of RAM have been allocated in total::

        gc.threshold(32768)

    To restore the default behaviour, only triggering garbage collection when out of memory::

        gc.threshold(-1)
    """

@overload
def threshold(amount: int) -> None:
    """
    Set or query the additional GC allocation threshold. Normally, a collection
    is triggered only when a new allocation cannot be satisfied, i.e. on an
    out-of-memory (OOM) condition. If this function is called, in addition to
    OOM, a collection will be triggered each time after *amount* bytes have been
    allocated (in total, since the previous time such an amount of bytes
    have been allocated). *amount* is usually specified as less than the
    full heap size, with the intention to trigger a collection earlier than when the
    heap becomes exhausted, and in the hope that an early collection will prevent
    excessive memory fragmentation. This is a heuristic measure, the effect
    of which will vary from application to application, as well as
    the optimal value of the *amount* parameter.

    Calling the function without argument will return the current value of
    the threshold. A value of -1 means a disabled allocation threshold.

    Admonition:Difference to CPython
       :class: attention

       This function is a MicroPython extension. CPython has a similar
       function - ``set_threshold()``, but due to different GC
       implementations, its signature and semantics are different.

    Examples
    ^^^^^^^^

    To trigger a garbage collection each time 32768 bytes of RAM have been allocated in total::

        gc.threshold(32768)

    To restore the default behaviour, only triggering garbage collection when out of memory::

        gc.threshold(-1)
    """
