"""
Module: 'samd' on micropython-v1.29.0-samd-SEEED_WIO_TERMINAL
"""

# MCU: {'variant': '', 'build': '', 'arch': 'armv7emsp', 'port': 'samd', 'board': 'SEEED_WIO_TERMINAL', 'board_id': 'SEEED_WIO_TERMINAL', 'mpy': 'v6.3', 'ver': '1.29.0', 'family': 'micropython', 'cpu': 'SAMD51P19A', 'version': '1.29.0'}
# Stubber: v1.28.6
from __future__ import annotations

from _typeshed import Incomplete

def pininfo(*args, **kwargs) -> Incomplete: ...

class Flash:
    def readblocks(self, *args, **kwargs) -> Incomplete: ...
    def writeblocks(self, *args, **kwargs) -> Incomplete: ...
    def ioctl(self, *args, **kwargs) -> Incomplete: ...
    def __init__(self, *argv, **kwargs) -> None: ...
