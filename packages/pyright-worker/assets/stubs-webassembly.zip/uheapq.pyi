"""
Module: 'uheapq' on micropython-v1.26.0-preview-webassembly-pyscript
"""

# MCU: {'family': 'micropython', 'version': '1.26.0-preview', 'build': '293', 'ver': '1.26.0-preview-293', 'port': 'webassembly', 'board': 'pyscript', 'board_id': 'pyscript', 'variant': '', 'cpu': 'Emscripten', 'mpy': 'v6.3', 'arch': ''}
# Stubber: v1.26.2
from __future__ import annotations
from typing import Any, Final, Generator
from _typeshed import Incomplete

def heappop(*args, **kwargs) -> Incomplete: ...
def heappush(*args, **kwargs) -> Incomplete: ...
def heapify(*args, **kwargs) -> Incomplete: ...
