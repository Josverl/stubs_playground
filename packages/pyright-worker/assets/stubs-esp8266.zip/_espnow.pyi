"""
Module: '_espnow' on micropython-v1.29.0-esp8266-ESP8266_GENERIC
"""

# MCU: {'variant': '', 'build': '', 'arch': 'xtensa', 'port': 'esp8266', 'board': 'ESP8266_GENERIC', 'board_id': 'ESP8266_GENERIC', 'mpy': 'v6.3', 'ver': '1.29.0', 'family': 'micropython', 'cpu': 'ESP8266', 'version': '1.29.0'}
# Stubber: v1.28.6
from __future__ import annotations

from typing import Final

from _typeshed import Incomplete

MAX_DATA_LEN: Final[int] = 250
MAX_TOTAL_PEER_NUM: Final[int] = 20
MAX_ENCRYPT_PEER_NUM: Final[int] = 6
ADDR_LEN: Final[int] = 6
KEY_LEN: Final[int] = 16

class ESPNowBase:
    def del_peer(self, *args, **kwargs) -> Incomplete: ...
    def config(self, *args, **kwargs) -> Incomplete: ...
    def recvinto(self, *args, **kwargs) -> Incomplete: ...
    def set_pmk(self, *args, **kwargs) -> Incomplete: ...
    def send(self, *args, **kwargs) -> Incomplete: ...
    def add_peer(self, *args, **kwargs) -> Incomplete: ...
    def active(self, *args, **kwargs) -> Incomplete: ...
    def __init__(self, *argv, **kwargs) -> None: ...
