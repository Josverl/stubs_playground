# Micropython v1.29.0 frozen stubs
