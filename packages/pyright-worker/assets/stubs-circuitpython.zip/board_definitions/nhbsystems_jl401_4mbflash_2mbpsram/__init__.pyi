# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for NHB Systems JL401-S3 4MB Flash 2MB PSRAM
 - port: espressif
 - board_id: nhbsystems_jl401_4mbflash_2mbpsram
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audioi2sin, audiomixer, audiomp3, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, canio, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, espcamera, espidf, espnow, espulp, fontio, fourwire, framebufferio, frequencyio, getpass, gifio, hashlib, i2cdisplaybus, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, max3421e, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, ps2io, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rtc, sdcardio, sdioio, select, sharpdisplay, socketpool, socketpool.socketpool.AF_INET6, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_midi, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import microcontroller


# Board Info:
board_id: str


# Pins:
BUTTON: microcontroller.Pin  # GPIO0
BOOT0: microcontroller.Pin  # GPIO0
D0: microcontroller.Pin  # GPIO0
NEOPIXEL: microcontroller.Pin  # GPIO1
NEOPIXEL_POWER: microcontroller.Pin  # GPIO2
SD_PWR: microcontroller.Pin  # GPIO3
D3: microcontroller.Pin  # GPIO3
D4: microcontroller.Pin  # GPIO4
D5: microcontroller.Pin  # GPIO5
D6: microcontroller.Pin  # GPIO6
D7: microcontroller.Pin  # GPIO7
A5: microcontroller.Pin  # GPIO8
D8: microcontroller.Pin  # GPIO8
D9: microcontroller.Pin  # GPIO9
I2C_POWER: microcontroller.Pin  # GPIO14
A4: microcontroller.Pin  # GPIO14
D14: microcontroller.Pin  # GPIO14
A3: microcontroller.Pin  # GPIO15
D15: microcontroller.Pin  # GPIO15
A2: microcontroller.Pin  # GPIO16
D16: microcontroller.Pin  # GPIO16
A1: microcontroller.Pin  # GPIO17
D17: microcontroller.Pin  # GPIO17
A0: microcontroller.Pin  # GPIO18
D18: microcontroller.Pin  # GPIO18
D21: microcontroller.Pin  # GPIO21
SD_CS: microcontroller.Pin  # GPIO10
D10: microcontroller.Pin  # GPIO10
MOSI: microcontroller.Pin  # GPIO11
D11: microcontroller.Pin  # GPIO11
SCK: microcontroller.Pin  # GPIO12
D12: microcontroller.Pin  # GPIO12
MISO: microcontroller.Pin  # GPIO13
D13: microcontroller.Pin  # GPIO13
D33: microcontroller.Pin  # GPIO33
D34: microcontroller.Pin  # GPIO34
D35: microcontroller.Pin  # GPIO35
D36: microcontroller.Pin  # GPIO36
D37: microcontroller.Pin  # GPIO37
D39: microcontroller.Pin  # GPIO39
TX: microcontroller.Pin  # GPIO43
D43: microcontroller.Pin  # GPIO43
RX: microcontroller.Pin  # GPIO44
D44: microcontroller.Pin  # GPIO44
SDA: microcontroller.Pin  # GPIO47
SCL: microcontroller.Pin  # GPIO48


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def STEMMA_I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def SPI() -> busio.SPI:
    """Returns the `busio.SPI` object for the board's designated SPI bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.SPI`.
    """

def UART() -> busio.UART:
    """Returns the `busio.UART` object for the board's designated UART bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.UART`.
    """


# Unmapped:
#   none
