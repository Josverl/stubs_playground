# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Waveshare ESP32-S3-Touch-AMOLED-2.41
 - port: espressif
 - board_id: waveshare_esp32_s3_amoled_241
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audioi2sin, audiomixer, audiomp3, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, canio, codeop, collections, countio, digitalio, displayio, dualbank, epaperdisplay, errno, espidf, espnow, espulp, fontio, fourwire, framebufferio, frequencyio, getpass, gifio, hashlib, i2cdisplaybus, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, max3421e, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, ps2io, pulseio, pwmio, qspibus, rainbowio, random, re, rgbmatrix, rotaryio, rtc, sdcardio, sdioio, select, sharpdisplay, socketpool, socketpool.socketpool.AF_INET6, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_midi, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: 
"""

# Imports
import displayio
import microcontroller


# Board Info:
board_id: str


# Pins:
BOOT: microcontroller.Pin  # GPIO0
KEY_BAT: microcontroller.Pin  # GPIO15
BAT_CONTROL: microcontroller.Pin  # GPIO16
LCD_POWER: microcontroller.Pin  # GPIO16
BAT_ADC: microcontroller.Pin  # GPIO17
SDA: microcontroller.Pin  # GPIO47
SCL: microcontroller.Pin  # GPIO48
TP_SDA: microcontroller.Pin  # GPIO47
TP_SCL: microcontroller.Pin  # GPIO48
TP_RESET: microcontroller.Pin  # GPIO3
TOUCH_SDA: microcontroller.Pin  # GPIO47
TOUCH_SCL: microcontroller.Pin  # GPIO48
TOUCH_RST: microcontroller.Pin  # GPIO3
RTC_SDA: microcontroller.Pin  # GPIO47
RTC_SCL: microcontroller.Pin  # GPIO48
IMU_SDA: microcontroller.Pin  # GPIO47
IMU_SCL: microcontroller.Pin  # GPIO48
EXIO_SDA: microcontroller.Pin  # GPIO47
EXIO_SCL: microcontroller.Pin  # GPIO48
USB_D_N: microcontroller.Pin  # GPIO19
USB_D_P: microcontroller.Pin  # GPIO20
TX: microcontroller.Pin  # GPIO43
RX: microcontroller.Pin  # GPIO44
LCD_CS: microcontroller.Pin  # GPIO9
LCD_CLK: microcontroller.Pin  # GPIO10
LCD_D0: microcontroller.Pin  # GPIO11
LCD_D1: microcontroller.Pin  # GPIO12
LCD_D2: microcontroller.Pin  # GPIO13
LCD_D3: microcontroller.Pin  # GPIO14
LCD_RESET: microcontroller.Pin  # GPIO21
DISPLAY_CS: microcontroller.Pin  # GPIO9
DISPLAY_SCK: microcontroller.Pin  # GPIO10
DISPLAY_D0: microcontroller.Pin  # GPIO11
DISPLAY_D1: microcontroller.Pin  # GPIO12
DISPLAY_D2: microcontroller.Pin  # GPIO13
DISPLAY_D3: microcontroller.Pin  # GPIO14
DISPLAY_RST: microcontroller.Pin  # GPIO21
SDIO_CLK: microcontroller.Pin  # GPIO4
SDIO_CMD: microcontroller.Pin  # GPIO5
SDIO_D0: microcontroller.Pin  # GPIO6
SDIO_D3: microcontroller.Pin  # GPIO2
IO0: microcontroller.Pin  # GPIO0
IO1: microcontroller.Pin  # GPIO1
IO3: microcontroller.Pin  # GPIO3
IO7: microcontroller.Pin  # GPIO7
IO8: microcontroller.Pin  # GPIO8
IO18: microcontroller.Pin  # GPIO18
IO40: microcontroller.Pin  # GPIO40
IO41: microcontroller.Pin  # GPIO41
IO42: microcontroller.Pin  # GPIO42
IO45: microcontroller.Pin  # GPIO45
IO46: microcontroller.Pin  # GPIO46


# Members:
"""Returns the `displayio.Display` object for the board's built in display.
The object created is a singleton, and uses the default parameter values for `displayio.Display`.
"""
DISPLAY: displayio.Display


# Unmapped:
#   none
