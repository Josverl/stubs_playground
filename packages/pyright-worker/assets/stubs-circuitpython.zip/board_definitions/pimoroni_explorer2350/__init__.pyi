# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Pimoroni Explorer
 - port: raspberrypi
 - board_id: pimoroni_explorer2350
 - NVM size: 4096
 - Included modules: _asyncio, _bleio, _bleio (HCI co-processor), _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiodelays, audiofilters, audiofreeverb, audiomixer, audiomp3, audiopwmio, binascii, bitbangio, bitmapfilter, bitmaptools, bitops, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, floppyio, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, i2cioexpander, i2ctarget, imagecapture, io, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, picodvi, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rp2pio, rtc, sdcardio, select, sharpdisplay, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_cdc, usb_hid, usb_host, usb_midi, usb_video, vectorio, warnings, watchdog, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import displayio
import microcontroller


# Board Info:
board_id: str


# Pins:
TX: microcontroller.Pin  # GPIO0
GP0: microcontroller.Pin  # GPIO0
RX: microcontroller.Pin  # GPIO1
GP1: microcontroller.Pin  # GPIO1
GP2: microcontroller.Pin  # GPIO2
GP3: microcontroller.Pin  # GPIO3
GP4: microcontroller.Pin  # GPIO4
GP5: microcontroller.Pin  # GPIO5
SERVO1: microcontroller.Pin  # GPIO9
GP9: microcontroller.Pin  # GPIO9
SERVO2: microcontroller.Pin  # GPIO8
GP8: microcontroller.Pin  # GPIO8
SERVO3: microcontroller.Pin  # GPIO7
GP7: microcontroller.Pin  # GPIO7
SERVO4: microcontroller.Pin  # GPIO6
GP6: microcontroller.Pin  # GPIO6
AUDIO: microcontroller.Pin  # GPIO12
GP12: microcontroller.Pin  # GPIO12
AMP_EN: microcontroller.Pin  # GPIO13
GP13: microcontroller.Pin  # GPIO13
SW_C: microcontroller.Pin  # GPIO14
GP14: microcontroller.Pin  # GPIO14
SW_B: microcontroller.Pin  # GPIO15
GP15: microcontroller.Pin  # GPIO15
SW_A: microcontroller.Pin  # GPIO16
GP16: microcontroller.Pin  # GPIO16
SW_X: microcontroller.Pin  # GPIO17
GP17: microcontroller.Pin  # GPIO17
SW_Y: microcontroller.Pin  # GPIO18
GP18: microcontroller.Pin  # GPIO18
SW_Z: microcontroller.Pin  # GPIO19
GP19: microcontroller.Pin  # GPIO19
SDA: microcontroller.Pin  # GPIO20
GP20: microcontroller.Pin  # GPIO20
SCL: microcontroller.Pin  # GPIO21
GP21: microcontroller.Pin  # GPIO21
SW_USER: microcontroller.Pin  # GPIO22
GP22: microcontroller.Pin  # GPIO22
LED: microcontroller.Pin  # GPIO25
GP25: microcontroller.Pin  # GPIO25
LCD_BL: microcontroller.Pin  # GPIO26
GP26: microcontroller.Pin  # GPIO26
LCD_CS: microcontroller.Pin  # GPIO27
GP27: microcontroller.Pin  # GPIO27
LCD_DC: microcontroller.Pin  # GPIO28
GP28: microcontroller.Pin  # GPIO28
GP29: microcontroller.Pin  # GPIO29
LCD_WR: microcontroller.Pin  # GPIO30
GP30: microcontroller.Pin  # GPIO30
LCD_RD: microcontroller.Pin  # GPIO31
GP31: microcontroller.Pin  # GPIO31
LCD_D0: microcontroller.Pin  # GPIO32
GP32: microcontroller.Pin  # GPIO32
LCD_D1: microcontroller.Pin  # GPIO33
GP33: microcontroller.Pin  # GPIO33
LCD_D2: microcontroller.Pin  # GPIO34
GP34: microcontroller.Pin  # GPIO34
LCD_D3: microcontroller.Pin  # GPIO35
GP35: microcontroller.Pin  # GPIO35
LCD_D4: microcontroller.Pin  # GPIO36
GP36: microcontroller.Pin  # GPIO36
LCD_D5: microcontroller.Pin  # GPIO37
GP37: microcontroller.Pin  # GPIO37
LCD_D6: microcontroller.Pin  # GPIO38
GP38: microcontroller.Pin  # GPIO38
LCD_D7: microcontroller.Pin  # GPIO39
GP39: microcontroller.Pin  # GPIO39
A0: microcontroller.Pin  # GPIO40
ADC0: microcontroller.Pin  # GPIO40
GP40: microcontroller.Pin  # GPIO40
A1: microcontroller.Pin  # GPIO41
ADC1: microcontroller.Pin  # GPIO41
GP41: microcontroller.Pin  # GPIO41
A2: microcontroller.Pin  # GPIO42
ADC2: microcontroller.Pin  # GPIO42
GP42: microcontroller.Pin  # GPIO42
A3: microcontroller.Pin  # GPIO43
ADC3: microcontroller.Pin  # GPIO43
GP43: microcontroller.Pin  # GPIO43
A4: microcontroller.Pin  # GPIO44
ADC4: microcontroller.Pin  # GPIO44
GP44: microcontroller.Pin  # GPIO44
A5: microcontroller.Pin  # GPIO45
ADC5: microcontroller.Pin  # GPIO45
GP45: microcontroller.Pin  # GPIO45


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def STEMMA_I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

"""Returns the `displayio.Display` object for the board's built in display.
The object created is a singleton, and uses the default parameter values for `displayio.Display`.
"""
DISPLAY: displayio.Display


# Unmapped:
#   none
