# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for WeAct Studio RP2350B Core
 - port: raspberrypi
 - board_id: weact_studio_rp2350b_core
 - NVM size: 4096
 - Included modules: _asyncio, _bleio, _bleio (HCI co-processor), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiodelays, audiofilewriter, audiofilters, audiofreeverb, audioi2sin, audiomixer, audiomp3, audiopwmio, audiospeed, binascii, bitbangio, bitmapfilter, bitmaptools, bitops, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, floppyio, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, i2ctarget, imagecapture, io, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, picodvi, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rp2pio, rtc, sdcardio, select, sharpdisplay, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_host, usb_midi, usb_video, vectorio, warnings, watchdog, zlib
 - Frozen libraries: 
"""

# Imports
import microcontroller


# Board Info:
board_id: str


# Pins:
GP0: microcontroller.Pin  # GPIO0
GP1: microcontroller.Pin  # GPIO1
GP2: microcontroller.Pin  # GPIO2
GP3: microcontroller.Pin  # GPIO3
GP4: microcontroller.Pin  # GPIO4
GP5: microcontroller.Pin  # GPIO5
GP6: microcontroller.Pin  # GPIO6
GP7: microcontroller.Pin  # GPIO7
GP8: microcontroller.Pin  # GPIO8
GP9: microcontroller.Pin  # GPIO9
GP10: microcontroller.Pin  # GPIO10
GP11: microcontroller.Pin  # GPIO11
GP12: microcontroller.Pin  # GPIO12
GP13: microcontroller.Pin  # GPIO13
GP14: microcontroller.Pin  # GPIO14
GP15: microcontroller.Pin  # GPIO15
GP16: microcontroller.Pin  # GPIO16
GP17: microcontroller.Pin  # GPIO17
GP18: microcontroller.Pin  # GPIO18
GP19: microcontroller.Pin  # GPIO19
GP20: microcontroller.Pin  # GPIO20
GP21: microcontroller.Pin  # GPIO21
GP22: microcontroller.Pin  # GPIO22
GP23: microcontroller.Pin  # GPIO23
BUTTON: microcontroller.Pin  # GPIO23
GP24: microcontroller.Pin  # GPIO24
GP25: microcontroller.Pin  # GPIO25
LED: microcontroller.Pin  # GPIO25
GP26: microcontroller.Pin  # GPIO26
GP27: microcontroller.Pin  # GPIO27
GP28: microcontroller.Pin  # GPIO28
GP29: microcontroller.Pin  # GPIO29
GP30: microcontroller.Pin  # GPIO30
GP31: microcontroller.Pin  # GPIO31
GP32: microcontroller.Pin  # GPIO32
GP33: microcontroller.Pin  # GPIO33
GP34: microcontroller.Pin  # GPIO34
GP35: microcontroller.Pin  # GPIO35
GP36: microcontroller.Pin  # GPIO36
GP37: microcontroller.Pin  # GPIO37
GP38: microcontroller.Pin  # GPIO38
GP39: microcontroller.Pin  # GPIO39
GP40: microcontroller.Pin  # GPIO40
A0: microcontroller.Pin  # GPIO40
GP40_A0: microcontroller.Pin  # GPIO40
GP41: microcontroller.Pin  # GPIO41
A1: microcontroller.Pin  # GPIO41
GP41_A1: microcontroller.Pin  # GPIO41
GP42: microcontroller.Pin  # GPIO42
A2: microcontroller.Pin  # GPIO42
GP42_A2: microcontroller.Pin  # GPIO42
GP43: microcontroller.Pin  # GPIO43
A3: microcontroller.Pin  # GPIO43
GP43_A3: microcontroller.Pin  # GPIO43
GP44: microcontroller.Pin  # GPIO44
A4: microcontroller.Pin  # GPIO44
GP44_A4: microcontroller.Pin  # GPIO44
GP45: microcontroller.Pin  # GPIO45
A5: microcontroller.Pin  # GPIO45
GP45_A5: microcontroller.Pin  # GPIO45
GP46: microcontroller.Pin  # GPIO46
A6: microcontroller.Pin  # GPIO46
GP46_A6: microcontroller.Pin  # GPIO46
GP47: microcontroller.Pin  # GPIO47
A7: microcontroller.Pin  # GPIO47
GP47_A7: microcontroller.Pin  # GPIO47


# Members:

# Unmapped:
#   none
