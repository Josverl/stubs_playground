# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Ikea Alpstuga Drop-In ESP32S3 4MB Flash 2MB PSRAM
 - port: espressif
 - board_id: ikea_alpstuga_esp32_s3
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audioi2sin, audiomixer, audiomp3, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, canio, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, espcamera, espidf, espnow, espulp, fontio, fourwire, framebufferio, frequencyio, getpass, gifio, hashlib, i2cdisplaybus, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, max3421e, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, ps2io, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rtc, sdcardio, sdioio, select, sharpdisplay, socketpool, socketpool.socketpool.AF_INET6, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_midi, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import microcontroller


# Board Info:
board_id: str


# Pins:
BUTTON: microcontroller.Pin  # GPIO0
BOOT0: microcontroller.Pin  # GPIO0
D0: microcontroller.Pin  # GPIO0
SDA: microcontroller.Pin  # GPIO3
D3: microcontroller.Pin  # GPIO3
SCL: microcontroller.Pin  # GPIO4
D4: microcontroller.Pin  # GPIO4
LED: microcontroller.Pin  # GPIO9
D9: microcontroller.Pin  # GPIO9
BUTTON_1: microcontroller.Pin  # GPIO5
D5: microcontroller.Pin  # GPIO5
BUTTON_2: microcontroller.Pin  # GPIO6
D6: microcontroller.Pin  # GPIO6
BUTTON_3: microcontroller.Pin  # GPIO8
D8: microcontroller.Pin  # GPIO8
NEOPIXEL: microcontroller.Pin  # GPIO33


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """


# Unmapped:
#   none
