# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Teenage Engineering ting fx EP-2350
 - port: raspberrypi
 - board_id: teenage_engineering_ep2350
 - NVM size: 4096
 - Included modules: _asyncio, _bleio, _bleio (HCI co-processor), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiodelays, audiofilewriter, audiofilters, audiofreeverb, audioi2sin, audiomixer, audiomp3, audiopwmio, audiospeed, binascii, bitbangio, bitmapfilter, bitmaptools, bitops, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, floppyio, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, i2ctarget, imagecapture, io, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rp2pio, rtc, sdcardio, select, sharpdisplay, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_host, usb_midi, usb_video, vectorio, warnings, watchdog, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import microcontroller


# Board Info:
board_id: str


# Pins:
GP0: microcontroller.Pin  # GPIO0
LED_WHITE1: microcontroller.Pin  # GPIO0
LED: microcontroller.Pin  # GPIO0
GP6: microcontroller.Pin  # GPIO6
LED_WHITE2: microcontroller.Pin  # GPIO6
GP4: microcontroller.Pin  # GPIO4
LED_WHITE3: microcontroller.Pin  # GPIO4
GP5: microcontroller.Pin  # GPIO5
LED_WHITE4: microcontroller.Pin  # GPIO5
GP16: microcontroller.Pin  # GPIO16
LED_RED1: microcontroller.Pin  # GPIO16
GP24: microcontroller.Pin  # GPIO24
LED_RED2: microcontroller.Pin  # GPIO24
GP18: microcontroller.Pin  # GPIO18
LED_RED3: microcontroller.Pin  # GPIO18
GP17: microcontroller.Pin  # GPIO17
LED_RED4: microcontroller.Pin  # GPIO17
GP21: microcontroller.Pin  # GPIO21
BUTTON_TOP: microcontroller.Pin  # GPIO21
GP3: microcontroller.Pin  # GPIO3
BUTTON_MIDDLE: microcontroller.Pin  # GPIO3
GP1: microcontroller.Pin  # GPIO1
BUTTON_BOTTOM: microcontroller.Pin  # GPIO1
GP19: microcontroller.Pin  # GPIO19
HANDLE_IN: microcontroller.Pin  # GPIO19
GP20: microcontroller.Pin  # GPIO20
HANDLE_OUT: microcontroller.Pin  # GPIO20
GP2: microcontroller.Pin  # GPIO2
POWER_HOLD: microcontroller.Pin  # GPIO2
GP14: microcontroller.Pin  # GPIO14
SDA: microcontroller.Pin  # GPIO14
GP15: microcontroller.Pin  # GPIO15
SCL: microcontroller.Pin  # GPIO15
GP8: microcontroller.Pin  # GPIO8
I2S_DIN: microcontroller.Pin  # GPIO8
GP9: microcontroller.Pin  # GPIO9
I2S_DOUT: microcontroller.Pin  # GPIO9
GP10: microcontroller.Pin  # GPIO10
I2S_WS: microcontroller.Pin  # GPIO10
GP11: microcontroller.Pin  # GPIO11
I2S_BIT_CLOCK: microcontroller.Pin  # GPIO11
GP12: microcontroller.Pin  # GPIO12
I2S_MCLK: microcontroller.Pin  # GPIO12
GP7: microcontroller.Pin  # GPIO7
GP13: microcontroller.Pin  # GPIO13
GP22: microcontroller.Pin  # GPIO22
GP23: microcontroller.Pin  # GPIO23
GP25: microcontroller.Pin  # GPIO25
GP26: microcontroller.Pin  # GPIO26
A0: microcontroller.Pin  # GPIO26
GP27: microcontroller.Pin  # GPIO27
A1: microcontroller.Pin  # GPIO27
GP28: microcontroller.Pin  # GPIO28
A2: microcontroller.Pin  # GPIO28
HANDLE_POSITION: microcontroller.Pin  # GPIO28
GP29: microcontroller.Pin  # GPIO29
A3: microcontroller.Pin  # GPIO29
VOLUME: microcontroller.Pin  # GPIO29


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """


# Unmapped:
#   none
