# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Studiolab Pico Expander
 - port: raspberrypi
 - board_id: studiolab_picoexpander
 - NVM size: 4096
 - Included modules: _asyncio, _bleio, _bleio (HCI co-processor), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiodelays, audiofilewriter, audiofilters, audiofreeverb, audioi2sin, audiomixer, audiomp3, audiopwmio, audiospeed, binascii, bitbangio, bitmapfilter, bitmaptools, bitops, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, cyw43, digitalio, displayio, epaperdisplay, errno, floppyio, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, i2ctarget, imagecapture, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rp2pio, rtc, sdcardio, select, sharpdisplay, socketpool, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_host, usb_midi, usb_video, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import microcontroller


# Board Info:
board_id: str


# Pins:
D0: microcontroller.Pin  # GPIO0
GP0: microcontroller.Pin  # GPIO0
D1: microcontroller.Pin  # GPIO1
GP1: microcontroller.Pin  # GPIO1
D2: microcontroller.Pin  # GPIO2
GP2: microcontroller.Pin  # GPIO2
D3: microcontroller.Pin  # GPIO3
GP3: microcontroller.Pin  # GPIO3
SDA: microcontroller.Pin  # GPIO4
D4: microcontroller.Pin  # GPIO4
GP4: microcontroller.Pin  # GPIO4
SCL: microcontroller.Pin  # GPIO5
D5: microcontroller.Pin  # GPIO5
GP5: microcontroller.Pin  # GPIO5
D6: microcontroller.Pin  # GPIO6
GP6: microcontroller.Pin  # GPIO6
D7: microcontroller.Pin  # GPIO7
GP7: microcontroller.Pin  # GPIO7
D8: microcontroller.Pin  # GPIO8
GP8: microcontroller.Pin  # GPIO8
D9: microcontroller.Pin  # GPIO9
GP9: microcontroller.Pin  # GPIO9
D10: microcontroller.Pin  # GPIO10
GP10: microcontroller.Pin  # GPIO10
D11: microcontroller.Pin  # GPIO11
GP11: microcontroller.Pin  # GPIO11
D12: microcontroller.Pin  # GPIO12
GP12: microcontroller.Pin  # GPIO12
D13: microcontroller.Pin  # GPIO13
GP13: microcontroller.Pin  # GPIO13
D14: microcontroller.Pin  # GPIO14
GP14: microcontroller.Pin  # GPIO14
BTN: microcontroller.Pin  # GPIO15
BUTTON: microcontroller.Pin  # GPIO15
D15: microcontroller.Pin  # GPIO15
GP15: microcontroller.Pin  # GPIO15
D16: microcontroller.Pin  # GPIO16
GP16: microcontroller.Pin  # GPIO16
D17: microcontroller.Pin  # GPIO17
GP17: microcontroller.Pin  # GPIO17
D18: microcontroller.Pin  # GPIO18
GP18: microcontroller.Pin  # GPIO18
D19: microcontroller.Pin  # GPIO19
GP19: microcontroller.Pin  # GPIO19
D20: microcontroller.Pin  # GPIO20
GP20: microcontroller.Pin  # GPIO20
D21: microcontroller.Pin  # GPIO21
GP21: microcontroller.Pin  # GPIO21
D22: microcontroller.Pin  # GPIO22
GP22: microcontroller.Pin  # GPIO22
A26: microcontroller.Pin  # GPIO26
GP26_A0: microcontroller.Pin  # GPIO26
GP26: microcontroller.Pin  # GPIO26
A0: microcontroller.Pin  # GPIO26
A27: microcontroller.Pin  # GPIO27
GP27_A1: microcontroller.Pin  # GPIO27
GP27: microcontroller.Pin  # GPIO27
A1: microcontroller.Pin  # GPIO27
A28: microcontroller.Pin  # GPIO28
GP28_A2: microcontroller.Pin  # GPIO28
GP28: microcontroller.Pin  # GPIO28
A2: microcontroller.Pin  # GPIO28
A3: microcontroller.Pin  # GPIO29
VOLTAGE_MONITOR: microcontroller.Pin  # GPIO29
SMPS_MODE: microcontroller.Pin  # CYW1
LED: microcontroller.Pin  # CYW0
VBUS_SENSE: microcontroller.Pin  # CYW2


# Members:
def STEMMA_I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def SPI() -> busio.SPI:
    """Returns the `busio.SPI` object for the board's designated SPI bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.SPI`.
    """


# Unmapped:
#   none
