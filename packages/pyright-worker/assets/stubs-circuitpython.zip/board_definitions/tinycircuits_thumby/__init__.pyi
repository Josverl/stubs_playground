# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for TinyCircuits Thumby
 - port: raspberrypi
 - board_id: tinycircuits_thumby
 - NVM size: 4096
 - Included modules: _asyncio, _bleio, _bleio (HCI co-processor), _pixelmap, _stage, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiomixer, audiomp3, audiopwmio, binascii, bitbangio, bitmapfilter, bitmaptools, bitops, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, floppyio, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, i2cioexpander, i2ctarget, imagecapture, io, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rp2pio, rtc, sdcardio, select, sharpdisplay, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_cdc, usb_hid, usb_host, usb_midi, usb_video, vectorio, warnings, watchdog, zlib
 - Frozen libraries: adafruit_displayio_ssd1306, adafruit_framebuf, adafruit_ssd1306
"""

# Imports
import busio
import displayio
import microcontroller


# Board Info:
board_id: str


# Pins:
EXT_TX: microcontroller.Pin  # GPIO0
EXT: microcontroller.Pin  # GPIO1
EXT_PU: microcontroller.Pin  # GPIO1
BUTTON_LEFT: microcontroller.Pin  # GPIO3
BUTTON_UP: microcontroller.Pin  # GPIO4
BUTTON_RIGHT: microcontroller.Pin  # GPIO5
BUTTON_DOWN: microcontroller.Pin  # GPIO6
BUTTON_1: microcontroller.Pin  # GPIO24
BUTTON_2: microcontroller.Pin  # GPIO27
SPEAKER: microcontroller.Pin  # GPIO28
ID3: microcontroller.Pin  # GPIO12
ID2: microcontroller.Pin  # GPIO13
ID1: microcontroller.Pin  # GPIO14
ID0: microcontroller.Pin  # GPIO15
VBUS_SENSE: microcontroller.Pin  # GPIO26


# Members:
def SPI() -> busio.SPI:
    """Returns the `busio.SPI` object for the board's designated SPI bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.SPI`.
    """

"""Returns the `displayio.Display` object for the board's built in display.
The object created is a singleton, and uses the default parameter values for `displayio.Display`.
"""
DISPLAY: displayio.Display


# Unmapped:
#     { MP_ROM_QSTR(MP_QSTR_OLED_CS), MP_ROM_PTR(CIRCUITPY_BOARD_OLED_CS) },
#     { MP_ROM_QSTR(MP_QSTR_OLED_DC), MP_ROM_PTR(CIRCUITPY_BOARD_OLED_DC) },
#     { MP_ROM_QSTR(MP_QSTR_OLED_RESET), MP_ROM_PTR(CIRCUITPY_BOARD_OLED_RESET) },
#     { MP_ROM_QSTR(MP_QSTR_SCK), MP_ROM_PTR(DEFAULT_SPI_BUS_SCK) },
#     { MP_ROM_QSTR(MP_QSTR_MOSI), MP_ROM_PTR(DEFAULT_SPI_BUS_MOSI) },
