# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for PCBCupid GLYPH S3
 - port: espressif
 - board_id: pcbcupid_glyph_s3
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audioi2sin, audiomixer, audiomp3, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, canio, codeop, collections, countio, digitalio, displayio, dualbank, epaperdisplay, errno, espidf, espnow, espulp, fontio, fourwire, framebufferio, frequencyio, getpass, gifio, hashlib, i2cdisplaybus, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, max3421e, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, ps2io, pulseio, pwmio, rainbowio, random, re, rgbmatrix, rotaryio, rtc, sdcardio, sdioio, select, sharpdisplay, socketpool, socketpool.socketpool.AF_INET6, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_midi, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import microcontroller


# Board Info:
board_id: str


# Pins:
A1: microcontroller.Pin  # GPIO1
D1: microcontroller.Pin  # GPIO1
A2: microcontroller.Pin  # GPIO2
D2: microcontroller.Pin  # GPIO2
SDA: microcontroller.Pin  # GPIO4
D4: microcontroller.Pin  # GPIO4
SCL: microcontroller.Pin  # GPIO5
D5: microcontroller.Pin  # GPIO5
A6: microcontroller.Pin  # GPIO6
D6: microcontroller.Pin  # GPIO6
A7: microcontroller.Pin  # GPIO7
D7: microcontroller.Pin  # GPIO7
A8: microcontroller.Pin  # GPIO8
D8: microcontroller.Pin  # GPIO8
A9: microcontroller.Pin  # GPIO9
D9: microcontroller.Pin  # GPIO9
A10: microcontroller.Pin  # GPIO10
D10: microcontroller.Pin  # GPIO10
D13: microcontroller.Pin  # GPIO13
D14: microcontroller.Pin  # GPIO14
D15: microcontroller.Pin  # GPIO15
D16: microcontroller.Pin  # GPIO16
D17: microcontroller.Pin  # GPIO17
D18: microcontroller.Pin  # GPIO18
LED: microcontroller.Pin  # GPIO21
SCK: microcontroller.Pin  # GPIO35
MOSI: microcontroller.Pin  # GPIO36
MISO: microcontroller.Pin  # GPIO37
TX: microcontroller.Pin  # GPIO43
RX: microcontroller.Pin  # GPIO44


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def SPI() -> busio.SPI:
    """Returns the `busio.SPI` object for the board's designated SPI bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.SPI`.
    """

def UART() -> busio.UART:
    """Returns the `busio.UART` object for the board's designated UART bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.UART`.
    """


# Unmapped:
#   none
