topics: dict[str, str]
