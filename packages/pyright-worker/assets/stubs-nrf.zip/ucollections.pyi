"""
Collection and container types.

MicroPython module: https://docs.micropython.org/en/v1.29.0/library/collections.html

CPython module: :mod:`python:collections` https://docs.python.org/3/library/collections.html .

This module implements advanced collection and container types to
hold/accumulate various objects.

---
Module: 'ucollections' on micropython-v1.29.0-nrf-SEEED_XIAO_NRF52
"""
# import module from stdlib/module
from collections import *